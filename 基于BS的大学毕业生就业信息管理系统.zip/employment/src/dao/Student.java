package dao;

public class Student 
{
  int id;
  String name;
  String pwd;
  String realname;
  String sex;
  int age;
  String birthday;
  String university;
  String email;
  String major;
  String xueli;
  String jianli;
  
  String specialty;
  String position;
  String salary;
  int date;//��Ч��
  String remark;
  String time;//����ʱ��
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getPwd() {
	return pwd;
}
public void setPwd(String pwd) {
	this.pwd = pwd;
}
public String getRealname() {
	return realname;
}
public void setRealname(String realname) {
	this.realname = realname;
}
public String getSex() {
	return sex;
}
public void setSex(String sex) {
	this.sex = sex;
}
public int getAge() {
	return age;
}
public void setAge(int age) {
	this.age = age;
}
public String getBirthday() {
	return birthday;
}
public void setBirthday(String birthday) {
	this.birthday = birthday;
}
public String getUniversity() {
	return university;
}
public void setUniversity(String university) {
	this.university = university;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getMajor() {
	return major;
}
public void setMajor(String major) {
	this.major = major;
}
public String getXueli() {
	return xueli;
}
public void setXueli(String xueli) {
	this.xueli = xueli;
}
public String getJianli() {
	return jianli;
}
public void setJianli(String jianli) {
	this.jianli = jianli;
}
public String getSpecialty() {
	return specialty;
}
public void setSpecialty(String specialty) {
	this.specialty = specialty;
}
public String getPosition() {
	return position;
}
public void setPosition(String position) {
	this.position = position;
}
public String getSalary() {
	return salary;
}
public void setSalary(String salary) {
	this.salary = salary;
}

public int getDate() {
	return date;
}
public void setDate(int date) {
	this.date = date;
}
public String getRemark() {
	return remark;
}
public void setRemark(String remark) {
	this.remark = remark;
}
public String getTime() {
	return time;
}
public void setTime(String time) {
	this.time = time;
}
  
}
